#include <bitset>
#include "bitset_bench.h"


int main(int argc, char **argv)
{
	output_to_csv_file(argv[0]);

	benchmark_bitset<std::bitset<1048576>>(20000);

	return 0;
}
