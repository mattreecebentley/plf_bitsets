#include <cstdio>
#include "plf_bitset.h"
#include "plf_rand.h"
#include "plf_nanotimer.h"


// To prevent compilers from optimizing out tests/loops:
int global_test = 0;

void message(const char *message_text, int number)
{
	global_test += number;
}


void failpass(const char *test_type, bool condition)
{
	global_test += condition;
}





int main()
{
	plf::nanotimer the_timer;

	plf::millisecond_delay(3000);
	the_timer.start();

	for (unsigned int counter = 0; counter != 4000; ++counter)
	{
		{
			plf::bitset<500134> values;

			unsigned int total = 0, total2 = 0;

			values.set();

			total = values.count();

			for (unsigned int index = 0; index != 500134; ++index)
			{
				total2 += values[index];
			}

			failpass("Set and count test", total == total2);

			total = 0;
			total2 = 0;


			values.reset();

			total = values.count();

			for (unsigned int index = 0; index != 500134; ++index)
			{
				total2 += values[index];
			}

			failpass("Reset and count test", total == total2);


			total = 0;
			total2 = 0;

			for (unsigned int index = 0; index != 500134; ++index)
			{
				const unsigned int num = plf::rand() & 1;
				values.set(index, num);
				total += num;
			}


			for (unsigned int index = 0; index != 500134; ++index)
			{
				total2 += values[index];
			}

			failpass("Set test 1", total == total2);

			plf::bitset<500134> flip_values = ~values;

			failpass("Flip test", flip_values.count() == 500134 - total2);


			plf::bitset<500134> and_values = values;
			and_values &= flip_values;

			failpass("And test", and_values.count() == 0);


			plf::bitset<500134> or_values = values;
			or_values |= flip_values;

			failpass("Or test", or_values.count() == 500134);


			plf::bitset<500134> xor_values = and_values;
			xor_values ^= or_values;

			failpass("Xor test", xor_values.count() == 500134);

			std::basic_string<char> values_output = values.to_string();
			std::basic_string<char> flip_output = flip_values.to_string();

			for (unsigned int index = 0; index != 500134; ++index)
			{
				if (values_output[index] - 48 != !(flip_output[index] - 48))
				{
					printf("Failed to_string comparison test");
					getchar();
					abort();
				}
			}

			message("String comparison test passed", flip_values.count());

			failpass("All test", or_values.all() && !values.all() && !flip_values.all() && !and_values.all());

			failpass("Any test", or_values.any() && values.any() && flip_values.any() && !and_values.any());

			failpass("None test", !or_values.none() && !values.none() && !flip_values.none() && and_values.none());

			and_values.set(100, 1);
			or_values.set(110, 0);

			failpass("operator[] test1", and_values[100] == true);
			failpass("operator[] test2", or_values[110] == false);
		}

		{
			const unsigned int bitset_size = 584;
			plf::bitset<bitset_size> shift_values, shifted_values;

			shift_values.set();
			shift_values >>= 4;
			failpass(">>= test 1", shift_values.count() == bitset_size - 4);


			for (unsigned int index = 0; index != bitset_size; ++index)
			{
				shift_values.set(index, plf::rand() & 1);
			}
			
			for (unsigned int shift_amount = 1; shift_amount != bitset_size + 1; ++shift_amount)
			{
				shifted_values = shift_values;
				shifted_values >>= shift_amount;
				
				for (unsigned int index = 0; index != bitset_size - shift_amount; ++index)
				{
					if (shift_values[index + shift_amount] != shifted_values[index])
					{
						printf("Failed >>= comparison test, shift_amount == %u, index = %u, shift_value = %u, shifted_value = %u\n", shift_amount, index, static_cast<unsigned int>(shift_values[index + shift_amount]), static_cast<unsigned int>(shifted_values[index]));
						printf("%s\n\n%s\n\n", shift_values.to_string().c_str(), shifted_values.to_string().c_str());
						
						getchar();
						abort();
					}
				}

				for (unsigned int index = bitset_size - shift_amount; index != bitset_size; ++index)
				{
					if (shifted_values[index] != 0)
					{
						printf("Failed >>= comparison remainder test, shift_amount == %u\n", shift_amount);
						printf("%s\n\n%s\n\n", shift_values.to_string().c_str(), shifted_values.to_string().c_str());
						
						getchar();
						abort();
					}
				}
				
			}
			
			message(">>= multipass test success", shifted_values.count());

			
			shift_values.set();
			shift_values <<= 100;
			failpass("<<= test 1", shift_values.count() == bitset_size - 100);
			
			for (unsigned int index = 0; index != bitset_size; ++index)
			{
				shift_values.set(index, plf::rand() & 1);
			}
			
			for (unsigned int shift_amount = 0; shift_amount != bitset_size + 1; ++shift_amount)
			{
				shifted_values = shift_values;
				shifted_values <<= shift_amount;
				
				for (unsigned int index = 0; index != shift_amount; ++index)
				{
					if (shifted_values[index] != 0)
					{
						printf("Failed <<= comparison remainder test, shift_amount == %u\n", shift_amount);
						printf("%s\n\n%s\n\n", shift_values.to_string().c_str(), shifted_values.to_string().c_str());
						
						getchar();
						abort();
					}
				}

				for (unsigned int index = shift_amount; index != bitset_size; ++index)
				{
					if (shift_values[index - shift_amount] != shifted_values[index])
					{
						printf("Failed <<= comparison test, shift_amount == %u\n", shift_amount);
						printf("%s\n\n%s\n\n", shift_values.to_string().c_str(), shifted_values.to_string().c_str());
						
						getchar();
						abort();
					}
				}
				
			}
			
			message("<<= multipass test success", shifted_values.count());
		}
	}


	double elapsed_time = the_timer.get_elapsed_ms();

	printf("Time: %gms.\n", elapsed_time);
	printf("Global int: %d.\n", global_test);

	return 0;
}
