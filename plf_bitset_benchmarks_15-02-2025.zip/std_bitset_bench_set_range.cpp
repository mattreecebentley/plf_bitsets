#include <cstdio>
#include <bitset>
#include "plf_rand.h"
#include "plf_nanotimer.h"


int main(int argc, char **argv)
{
	std::bitset<128000> bs;
	plf::nanotimer timer;

	plf::millisecond_delay(1000);
	timer.start();

	for (unsigned int counter = 0; counter != 100000; ++counter)
	{
		for (unsigned int start = plf::rand() % 127999, end = start + (plf::rand() % (128000 - start)); start != end; ++start)
		{
			bs.set(start);
		}
		
		for (unsigned int start = plf::rand() % 127999, end = start + (plf::rand() % (128000 - start)); start != end; ++start)
		{
			bs.reset(start);
		}
	}


	printf("Time: %g\n Total: %llu", timer.get_elapsed_ms(), bs.count());

	return 0;
}
