#include <cstdio>
#include "plf_bitset.h"
#include "plf_rand.h"
#include "plf_nanotimer.h"


int main(int argc, char **argv)
{
	plf::bitset<128000> bs;
	plf::nanotimer timer;

	plf::millisecond_delay(1000);
	timer.start();

	for (unsigned int counter = 0; counter != 100000; ++counter)
	{
		unsigned int start = plf::rand() % 127999;
		bs.set_range(start, start + (plf::rand() % (128000 - start)));
		start = plf::rand() % 127999;
		bs.reset_range(start, start + (plf::rand() % (128000 - start)));
	}

	
	printf("Time: %g\n Total: %llu", timer.get_elapsed_ms(), bs.count());

	return 0;
}
