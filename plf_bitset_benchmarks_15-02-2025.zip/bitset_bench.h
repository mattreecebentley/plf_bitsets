#include "plf_rand.h"
#include "plf_nanotimer.h"
#include <cstdio>


template <class bitset_type>
void benchmark_bitset_core(const unsigned int number_of_runs)
{
	printf("construction, destruction, set(value), iterate, random access, flip, or, and, xor, to_string, shift >>=, shift <<=\n\n");

	double total = 0, construction_time_total = 0, destruction_time_total = 0, insert_time_total = 0, iterate_time_total = 0, random_access_time_total = 0, flip_time_total = 0, or_time_total = 0, and_time_total = 0, xor_time_total = 0, to_string_time_total = 0, shift_time_total = 0, shift_left_time_total = 0;
	plf::nanotimer construction_time, destruction_time, insert_time, iterate_time, random_access_time, flip_time, or_time, and_time, xor_time, to_string_time, shift_time, shift_left_time;

	destruction_time.start();

	for (unsigned int run_number = 0; run_number != number_of_runs; ++run_number)
	{
		destruction_time_total += destruction_time.get_elapsed_ms();
		construction_time.start();
		bitset_type container, container2, container3;
		construction_time_total += construction_time.get_elapsed_ms();
		const unsigned int number_of_elements = container.size();

		insert_time.start();

		for (unsigned int element_number = 0; element_number != number_of_elements; ++element_number)
		{
			container.set(element_number, plf::rand() & 1);
			container3.set(element_number, plf::rand() & 1);
		}

		insert_time_total += insert_time.get_elapsed_ms();

		iterate_time.start();

		for (unsigned int element_number = 0; element_number != number_of_elements; ++element_number)
		{
			total += container[element_number];
		}

		iterate_time_total += iterate_time.get_elapsed_ms();

		random_access_time.start();

		for (unsigned int number = 0; number != number_of_elements; ++number)
		{
			total += container[plf::rand() % number_of_elements];
		}

		random_access_time_total += random_access_time.get_elapsed_ms();

		flip_time.start();

		container2 = ~container;
		~container3;

		flip_time_total += flip_time.get_elapsed_ms();

		and_time.start();

		container2 &= container;
		container3 &= container;

		and_time_total += and_time.get_elapsed_ms();

		or_time.start();

		container2 |= container;
		container3 |= container2;

		or_time_total += or_time.get_elapsed_ms();

		xor_time.start();

		container2 ^= container;
		container3 ^= container;

		xor_time_total += xor_time.get_elapsed_ms();

		{
			to_string_time.start();

			std::basic_string<char> values_output(container.to_string());

			to_string_time_total += to_string_time.get_elapsed_ms();

			total += values_output.c_str()[plf::rand() % number_of_elements];
		} // to avoid factoring basic_string destruction into destruction time calculations at end of loop

		shift_time.start();

		for (unsigned int counter = 0; counter != 100; ++counter)
		{
			container >>= plf::rand() & 255;
		}

		shift_time_total += shift_time.get_elapsed_ms();

		shift_left_time.start();

		for (unsigned int counter = 0; counter != 100; ++counter)
		{
			container <<= plf::rand() & 255;
		}

		shift_left_time_total += shift_left_time.get_elapsed_ms();

		total += container[plf::rand() % number_of_elements] + container2[plf::rand() % number_of_elements] + container3[plf::rand() % number_of_elements];

		destruction_time.start();
	}

	destruction_time_total += destruction_time.get_elapsed_ms();

	printf("%g, %g, %g, %g, %g, %g, %g, %g, %g, %g, %g, %g\n Total: %g\n\n", (construction_time_total / static_cast<double>(number_of_runs))
	,(destruction_time_total / static_cast<double>(number_of_runs))
	, (insert_time_total / static_cast<double>(number_of_runs))
	, (iterate_time_total / static_cast<double>(number_of_runs))
	, (random_access_time_total / static_cast<double>(number_of_runs))
	, (flip_time_total / static_cast<double>(number_of_runs))
	, (or_time_total / static_cast<double>(number_of_runs))
	, (and_time_total / static_cast<double>(number_of_runs))
	, (xor_time_total / static_cast<double>(number_of_runs))
	, (to_string_time_total / static_cast<double>(number_of_runs))
	, (shift_time_total / static_cast<double>(number_of_runs))
	, (shift_left_time_total / static_cast<double>(number_of_runs)), total);
}



template <class bitset_type>
void benchmark_bitset(const unsigned int number_of_runs)
{
	plf::millisecond_delay(500);

	printf("Cache warm-up runs:\n");
	benchmark_bitset_core<bitset_type>((number_of_runs / 10) + 1);

	printf("Benchmark runs:\n");
	benchmark_bitset_core<bitset_type>(number_of_runs);

}


void output_to_csv_file(char* filename)
{
	freopen("errors.log", "w", stderr);
	char logfile[512];
	sprintf(logfile, "%s.csv", filename);
	printf("Outputting results to logfile %s.\n Please wait while program completes. This may take a while. Program will close once complete.\n", logfile);
	freopen(logfile, "w", stdout);
}
